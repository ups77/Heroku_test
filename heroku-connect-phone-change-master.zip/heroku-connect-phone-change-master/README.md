# Heroku Connect Sample - Phone Change

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy?template=https://github.com/jamesward/heroku-connect-phone-change)

# Local Dev

    PGSSLMODE=require DATABASE_URL=postgres://foo:bar@asdf.com:5432/1234 npm start
